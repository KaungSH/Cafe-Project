package cafe.project.YatiWinLatt.repositories.entities;

public class BranchStatus {

	private String branch_status_id;
	private String name;

	public BranchStatus() {
	}

	public BranchStatus(String branch_status_id, String name) {
		this.branch_status_id = branch_status_id;
		this.name = name;
	}

	public String getBranch_status_id() {
		return branch_status_id;
	}

	public void setBranch_status_id(String branch_status_id) {
		this.branch_status_id = branch_status_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
