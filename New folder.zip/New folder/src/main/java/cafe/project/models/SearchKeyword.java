package cafe.project.models;

public class SearchKeyword {
	
	private String keyword;
	
	public SearchKeyword() {}
	
	public SearchKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	
	

}
