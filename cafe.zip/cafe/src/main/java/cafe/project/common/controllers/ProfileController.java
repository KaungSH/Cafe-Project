package cafe.project.common.controllers;



import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@RequestMapping("/admin")
public class ProfileController {

    @GetMapping("/profile")
    public String showProfile() {
        return "admin/profile";
    }
    @PostMapping("/profile")
    public String saveProfile() {
        return "redirect:/admin/profile";
    }
}