package cafe.project;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;

import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import com.itextpdf.text.pdf.draw.LineSeparator;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;

import java.math.BigDecimal;

import java.text.DecimalFormat;

import java.util.List;
import java.util.Map;


public class ReceiptPdfGenerator {

    private String orderTime;


    // =========================================================
    // 1. Generate PDF as byte[]
    // =========================================================

    public byte[] generateReceiptPdfBytes(
            String orderId,
            Map<String, Object> orderData,
            List<Map<String, Object>> items) throws Exception {

        ByteArrayOutputStream baos =
                new ByteArrayOutputStream();

        writeReceiptToStream(
                baos,
                orderId,
                orderData,
                items
        );

        return baos.toByteArray();
    }


    // =========================================================
    // 2. Generate PDF as File
    // =========================================================

    public void generateReceipt(
            String filePath,
            String orderId,
            Map<String, Object> orderData,
            List<Map<String, Object>> items) throws Exception {

        try (FileOutputStream fos =
                     new FileOutputStream(filePath)) {

            writeReceiptToStream(
                    fos,
                    orderId,
                    orderData,
                    items
            );
        }
    }


    // =========================================================
    // 3. Common Receipt Drawing Method
    // =========================================================

    private void writeReceiptToStream(
            OutputStream outputStream,
            String orderId,
            Map<String, Object> orderData,
            List<Map<String, Object>> items) throws Exception {


        // =====================================================
        // 80mm Thermal Printer
        // =====================================================

        Rectangle receiptSize =
                new Rectangle(226, 360);

        Document document =
                new Document(
                        receiptSize,
                        10,
                        10,
                        10,
                        10
                );

        PdfWriter.getInstance(
                document,
                outputStream
        );

        document.open();


        // =====================================================
        // Fonts
        // =====================================================

        Font titleFont =
                new Font(
                        Font.FontFamily.HELVETICA,
                        10,
                        Font.BOLD
                );

        Font tokenFont =
                new Font(
                        Font.FontFamily.HELVETICA,
                        9,
                        Font.BOLD
                );

        Font boldFont =
                new Font(
                        Font.FontFamily.HELVETICA,
                        8,
                        Font.BOLD
                );

        Font normalFont =
                new Font(
                        Font.FontFamily.HELVETICA,
                        7,
                        Font.NORMAL
                );

        Font italicFont =
                new Font(
                        Font.FontFamily.HELVETICA,
                        6.5f,
                        Font.ITALIC
                );


        // =====================================================
        // Currency Format
        // =====================================================

        DecimalFormat currencyFormat =
                new DecimalFormat("#,##0");


        // =====================================================
        // Divider
        // =====================================================

        LineSeparator separator =
                new LineSeparator();

        separator.setLineColor(
                BaseColor.GRAY
        );

        separator.setLineWidth(0.5f);


        // =====================================================
        // Branch Name
        // =====================================================

        String branchName =
                "Cafe Luft";

        if (orderData != null
                && orderData.get("branch_name") != null) {

            String rawBranch =
                    orderData.get(
                            "branch_name"
                    ).toString();

            if (rawBranch.contains("-")) {

                branchName =
                        rawBranch
                                .split("-")[0]
                                .trim();

            } else {

                branchName =
                        rawBranch;
            }
        }


        Paragraph branch =
                new Paragraph(
                        branchName.toUpperCase(),
                        titleFont
                );

        branch.setAlignment(
                Element.ALIGN_CENTER
        );

        document.add(branch);


        // =====================================================
        // Token Number
        // =====================================================

        if (orderData != null
                && orderData.get("token_number") != null) {

            Paragraph token =
                    new Paragraph(
                            "TOKEN: #"
                                    + orderData.get(
                                            "token_number"
                                    ),
                            tokenFont
                    );

            token.setAlignment(
                    Element.ALIGN_CENTER
            );

            document.add(token);
        }


        document.add(
                new Chunk(separator)
        );


        // =====================================================
        // Cashier Information
        // =====================================================

        String empId =
                (
                        orderData != null
                        && orderData.get(
                                "employee_id"
                        ) != null
                )
                ? orderData.get(
                        "employee_id"
                ).toString().trim()
                : "";


        String empName =
                (
                        orderData != null
                        && orderData.get(
                                "employee_name"
                        ) != null
                )
                ? orderData.get(
                        "employee_name"
                ).toString().trim()
                : "";


        String cashierDisplay =
                "-";


        if (!empId.isEmpty()
                && !empName.isEmpty()) {

            cashierDisplay =
                    empId + " (" + empName + ")";

        } else if (!empName.isEmpty()) {

            cashierDisplay =
                    empName;

        } else if (!empId.isEmpty()) {

            cashierDisplay =
                    empId;
        }


        // =====================================================
        // Date / Time
        // =====================================================

        orderTime = "-";


        if (orderData != null) {

            if (orderData.get(
                    "created_time"
            ) != null) {

                orderTime =
                        orderData.get(
                                "created_time"
                        ).toString();

            } else if (
                    orderData.get(
                            "received_time"
                    ) != null) {

                orderTime =
                        orderData.get(
                                "received_time"
                        ).toString();
            }
        }


        document.add(
                new Paragraph(
                        "Order ID : " + orderId,
                        boldFont
                )
        );

        document.add(
                new Paragraph(
                        "Cashier  : "
                                + cashierDisplay,
                        boldFont
                )
        );

        document.add(
                new Paragraph(
                        "Date/Time: "
                                + orderTime,
                        boldFont
                )
        );


        document.add(
                new Chunk(separator)
        );


        // =====================================================
        // Items Table
        // =====================================================

        PdfPTable table =
                new PdfPTable(4);

        table.setWidthPercentage(100);

        table.setWidths(
                new float[]{
                        4.5f,
                        1.2f,
                        2.0f,
                        2.3f
                }
        );


        // Table Header

        addTableCell(
                table,
                "Item",
                boldFont,
                Element.ALIGN_LEFT
        );

        addTableCell(
                table,
                "Qty",
                boldFont,
                Element.ALIGN_CENTER
        );

        addTableCell(
                table,
                "Price",
                boldFont,
                Element.ALIGN_RIGHT
        );

        addTableCell(
                table,
                "Total",
                boldFont,
                Element.ALIGN_RIGHT
        );


        // =====================================================
        // Calculate Item Total
        // =====================================================

        BigDecimal calculatedTotal =
                BigDecimal.ZERO;


        if (items != null
                && !items.isEmpty()) {


            for (Map<String, Object> item :
                    items) {


                // Product Name

                String pName =
                        item.get(
                                "product_name"
                        ) != null
                        ? item.get(
                                "product_name"
                        ).toString()
                        : "Item";


                // Size

                String sName = "";

                if (item.get(
                        "size_name"
                ) != null) {

                    sName =
                            " ("
                                    + item.get(
                                            "size_name"
                                    )
                                    + ")";
                }


                // Quantity

                int qty =
                        item.get(
                                "quantity"
                        ) != null
                        ? (
                            (Number) item.get(
                                    "quantity"
                            )
                          ).intValue()
                        : 1;


                // Price

                BigDecimal price =
                        item.get(
                                "price"
                        ) != null
                        ? new BigDecimal(
                                item.get(
                                        "price"
                                ).toString()
                        )
                        : BigDecimal.ZERO;


                // Line Total

                BigDecimal lineTotal =
                        price.multiply(
                                BigDecimal.valueOf(
                                        qty
                                )
                        );


                calculatedTotal =
                        calculatedTotal.add(
                                lineTotal
                        );


                // Remark

                String remark =
                        item.get(
                                "remark"
                        ) != null
                        ? item.get(
                                "remark"
                        ).toString()
                        : "";


                // Product Row

                addTableCell(
                        table,
                        pName + sName,
                        normalFont,
                        Element.ALIGN_LEFT
                );

                addTableCell(
                        table,
                        String.valueOf(qty),
                        normalFont,
                        Element.ALIGN_CENTER
                );

                addTableCell(
                        table,
                        currencyFormat.format(
                                price
                        ),
                        normalFont,
                        Element.ALIGN_RIGHT
                );

                addTableCell(
                        table,
                        currencyFormat.format(
                                lineTotal
                        ),
                        normalFont,
                        Element.ALIGN_RIGHT
                );


                // =================================================
                // Remark
                // =================================================

                if (!remark.trim().isEmpty()) {

                    PdfPCell remarkCell =
                            new PdfPCell(
                                    new Phrase(
                                            " * "
                                                    + remark,
                                            italicFont
                                    )
                            );

                    remarkCell.setColspan(4);

                    remarkCell.setBorder(
                            Rectangle.NO_BORDER
                    );

                    remarkCell.setPaddingLeft(5);

                    remarkCell.setPaddingBottom(3);

                    table.addCell(
                            remarkCell
                    );
                }
            }
        }


        document.add(table);


        document.add(
                new Chunk(separator)
        );


        // =====================================================
        // SUBTOTAL
        // =====================================================

        BigDecimal subtotal =
                calculatedTotal;


        if (orderData != null
                && orderData.get(
                        "subtotal"
                ) != null) {

            subtotal =
                    new BigDecimal(
                            orderData
                                    .get("subtotal")
                                    .toString()
                    );
        }


        // =====================================================
        // DISCOUNT
        // =====================================================

        BigDecimal discountAmount =
                BigDecimal.ZERO;


        if (orderData != null
                && orderData.get(
                        "discount_amount"
                ) != null) {

            discountAmount =
                    new BigDecimal(
                            orderData
                                    .get(
                                            "discount_amount"
                                    )
                                    .toString()
                    );
        }


        // =====================================================
        // FINAL TOTAL
        // =====================================================

        BigDecimal finalTotal =
                subtotal.subtract(
                        discountAmount
                );


        // =====================================================
        // SUBTOTAL DISPLAY
        // =====================================================

        Paragraph subtotalPara =
                new Paragraph(
                        "Subtotal : "
                                + currencyFormat.format(
                                        subtotal
                                )
                                + " MMK",
                        normalFont
                );

        subtotalPara.setAlignment(
                Element.ALIGN_RIGHT
        );

        document.add(
                subtotalPara
        );


     // =====================================================
        // DISCOUNT DISPLAY
        // =====================================================

        String discountSign = discountAmount.compareTo(BigDecimal.ZERO) > 0 ? "-" : "";

        Paragraph discountPara =
                new Paragraph(
                        "Discount : "
                                + discountSign
                                + currencyFormat.format(discountAmount)
                                + " %",
                        normalFont
                );

        discountPara.setAlignment(
                Element.ALIGN_RIGHT
        );

        document.add(
                discountPara
        );


        // =====================================================
        // Divider
        // =====================================================

        document.add(
                new Chunk(separator)
        );


        // =====================================================
        // FINAL TOTAL DISPLAY
        // =====================================================

        Paragraph totalPara =
                new Paragraph(
                        "TOTAL : "
                                + currencyFormat.format(
                                        finalTotal
                                )
                                + " MMK",
                        boldFont
                );


        totalPara.setAlignment(
                Element.ALIGN_RIGHT
        );


        document.add(
                totalPara
        );


        // =====================================================
        // PAYMENT METHOD
        // =====================================================

        String payMethod =
                (
                        orderData != null
                        && orderData.get(
                                "payment_method"
                        ) != null
                )
                ? orderData.get(
                        "payment_method"
                ).toString()
                : "N/A";


        Paragraph payPara =
                new Paragraph(
                        "Paymethod: "
                                + payMethod,
                        normalFont
                );


        payPara.setAlignment(
                Element.ALIGN_RIGHT
        );


        document.add(
                payPara
        );


        // =====================================================
        // PAYMENT NOTE
        // =====================================================

        if (orderData != null
                && orderData.get(
                        "payment_note"
                ) != null
                && !orderData.get(
                        "payment_note"
                ).toString().trim().isEmpty()) {


            Paragraph notePara =
                    new Paragraph(
                            "Note: "
                                    + orderData.get(
                                            "payment_note"
                                    ).toString(),
                            italicFont
                    );


            notePara.setAlignment(
                    Element.ALIGN_RIGHT
            );


            document.add(
                    notePara
            );
        }


        // =====================================================
        // Footer Divider
        // =====================================================

        document.add(
                new Chunk(separator)
        );


        // =====================================================
        // Footer
        // =====================================================

        Paragraph footer =
                new Paragraph(
                        "THANK YOU! PLEASE COME AGAIN",
                        boldFont
                );


        footer.setAlignment(
                Element.ALIGN_CENTER
        );


        document.add(
                footer
        );


        // =====================================================
        // Close PDF
        // =====================================================

        document.close();
    }


    // =========================================================
    // Helper Method
    // =========================================================

    private void addTableCell(
            PdfPTable table,
            String text,
            Font font,
            int alignment) {


        PdfPCell cell =
                new PdfPCell(
                        new Phrase(
                                text,
                                font
                        )
                );


        cell.setBorder(
                Rectangle.NO_BORDER
        );


        cell.setHorizontalAlignment(
                alignment
        );


        cell.setPadding(2);


        table.addCell(cell);
    }
}
