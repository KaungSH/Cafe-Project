package cafe.project;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Map;

import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

public class ReceiptPdfGenerator {

    public byte[] generateReceiptPdfBytes(String orderId, Map<String, Object> orderData, List<Map<String, Object>> items) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        // 80mm POS Slip Width (~226pt)
        Rectangle pageSize = new Rectangle(226, 620);
        Document document = new Document(pageSize, 8, 8, 10, 10);

        try {
            PdfWriter.getInstance(document, baos);
            document.open();

            // Font Styles (Courier Monospace font for exact receipt look)
            Font titleFont = FontFactory.getFont(FontFactory.COURIER_BOLD, 12, Color.BLACK);
            Font tokenFont = FontFactory.getFont(FontFactory.COURIER_BOLD, 10, Color.BLACK);
            Font boldFont  = FontFactory.getFont(FontFactory.COURIER_BOLD, 7.5f, Color.BLACK);
            Font regularFont = FontFactory.getFont(FontFactory.COURIER, 7.5f, Color.BLACK);
            Font remarkFont  = FontFactory.getFont(FontFactory.COURIER_OBLIQUE, 6.8f, Color.DARK_GRAY);

            
            // Container Table for the Outer Border
            PdfPTable containerTable = new PdfPTable(1);
            containerTable.setWidthPercentage(100);

            PdfPCell containerCell = new PdfPCell();
            containerCell.setBorder(Rectangle.BOX);
            containerCell.setBorderWidth(1.2f);
            containerCell.setPadding(6f);

            // Inner Table for Content
            PdfPTable mainTable = new PdfPTable(1);
            mainTable.setWidthPercentage(100);

            // 1. Header (Cafe Luft & Token)
            String branch = orderData.get("branch_name") != null ? orderData.get("branch_name").toString() : "Cafe Luft";
            String token = orderData.get("token_number") != null ? orderData.get("token_number").toString() : "12";

            mainTable.addCell(createCell(branch, titleFont, Element.ALIGN_CENTER, 0, false));
            mainTable.addCell(createCell("TOKEN: #" + token, tokenFont, Element.ALIGN_CENTER, 0, false));
            addDivider(mainTable);

            // 2. Order Metadata
            String cashier = orderData.get("employee_name") != null ? orderData.get("employee_name").toString() :
                            (orderData.get("employee_id") != null ? orderData.get("employee_id").toString() : "EMP-004");
            String createdTime = orderData.get("created_time") != null ? orderData.get("created_time").toString() : "2026-10-01 23:20:15";

            mainTable.addCell(createCell("Order ID : " + orderId, regularFont, Element.ALIGN_LEFT, 0, false));
            mainTable.addCell(createCell("Cashier  : " + cashier, regularFont, Element.ALIGN_LEFT, 0, false));
            mainTable.addCell(createCell("Date/Time: " + createdTime, regularFont, Element.ALIGN_LEFT, 0, false));
            addDivider(mainTable);

            // 3. Items Table (Item, Qty, Price, Total)
            PdfPTable itemsTable = new PdfPTable(4);
            itemsTable.setWidthPercentage(100);
            itemsTable.setWidths(new float[]{4.2f, 1.1f, 2.3f, 2.4f});

            // Columns Header
            itemsTable.addCell(createCell("Item", boldFont, Element.ALIGN_LEFT, 0, false));
            itemsTable.addCell(createCell("Qty", boldFont, Element.ALIGN_CENTER, 0, false));
            itemsTable.addCell(createCell("Price", boldFont, Element.ALIGN_RIGHT, 0, false));
            itemsTable.addCell(createCell("Total", boldFont, Element.ALIGN_RIGHT, 0, false));

            if (items != null) {
                for (Map<String, Object> item : items) {
                    String name = item.get("product_name") != null ? item.get("product_name").toString() : "";
                    int qty = item.get("quantity") != null ? Integer.parseInt(item.get("quantity").toString()) : 1;
                    double price = item.get("price") != null ? Double.parseDouble(item.get("price").toString()) : 0.0;
                    double total = qty * price;

                    itemsTable.addCell(createCell(name, regularFont, Element.ALIGN_LEFT, 0, false));
                    itemsTable.addCell(createCell(String.valueOf(qty), regularFont, Element.ALIGN_CENTER, 0, false));
                    itemsTable.addCell(createCell(String.format("%,.0f", price), regularFont, Element.ALIGN_RIGHT, 0, false));
                    itemsTable.addCell(createCell(String.format("%,.0f", total), regularFont, Element.ALIGN_RIGHT, 0, false));

                    // Remark Sub-row
                    Object remarkObj = item.get("remark");
                    if (remarkObj != null && !remarkObj.toString().trim().isEmpty()) {
                        PdfPCell remarkCell = createCell(" * " + remarkObj.toString(), remarkFont, Element.ALIGN_LEFT, 0, false);
                        remarkCell.setColspan(4);
                        itemsTable.addCell(remarkCell);
                    }
                }
            }

            PdfPCell tableHolder = new PdfPCell(itemsTable);
            tableHolder.setBorder(Rectangle.NO_BORDER);
            tableHolder.setPadding(0);
            mainTable.addCell(tableHolder);

            addDivider(mainTable);

            // 4. Totals & Payment Details
            double totalAmount = 0.0;
            if (orderData.get("total_amount") != null) {
                totalAmount = Double.parseDouble(orderData.get("total_amount").toString());
            }
            String payMethod = orderData.get("payment_method") != null ? orderData.get("payment_method").toString() : "KPay";
            String note = orderData.get("note") != null ? orderData.get("note").toString() : "TXN-89472911";

            mainTable.addCell(createCell("TOTAL : " + String.format("%,.0f", totalAmount) + " MMK", boldFont, Element.ALIGN_RIGHT, 0, false));
            mainTable.addCell(createCell("PayMethod: " + payMethod, regularFont, Element.ALIGN_RIGHT, 0, false));
            mainTable.addCell(createCell("Note: " + note, regularFont, Element.ALIGN_RIGHT, 0, false));

            addDivider(mainTable);

            // 5. Footer Message
            mainTable.addCell(createCell("THANK YOU! PLEASE COME AGAIN", boldFont, Element.ALIGN_CENTER, 0, false));

            // Assemble and Add to Document
            containerCell.addElement(mainTable);
            containerTable.addCell(containerCell);

            document.add(containerTable);
            document.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return baos.toByteArray();
    }

    private void addDivider(PdfPTable table) {
        PdfPCell divider = new PdfPCell();
        divider.setBorder(Rectangle.BOTTOM);
        divider.setBorderWidth(0.8f);
        divider.setBorderColor(Color.DARK_GRAY);
        divider.setFixedHeight(4f);
        table.addCell(divider);

        // Spacer below divider
        PdfPCell spacer = new PdfPCell(new Phrase(" "));
        spacer.setBorder(Rectangle.NO_BORDER);
        spacer.setFixedHeight(3f);
        table.addCell(spacer);
    }

    private PdfPCell createCell(String text, Font font, int alignment, int colSpan, boolean hasBorder) {
        PdfPCell cell = new PdfPCell(new Phrase(text, font));
        cell.setHorizontalAlignment(alignment);
        cell.setBorder(hasBorder ? Rectangle.BOX : Rectangle.NO_BORDER);
        cell.setPaddingTop(1.5f);
        cell.setPaddingBottom(1.5f);
        if (colSpan > 1) {
            cell.setColspan(colSpan);
        }
        return cell;
    }
}