package cafe.project.YinminThiriSoe.repositories.entities;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Employee {

	private String employeeId;
	private String name;
	private String email;
	private String photoPath;
	private String password;
	private String employeeStatusId;
	private String phone;
	private double salary;
	private String address;
	private LocalDate dob;
	private String genderId;
	private String employeeRoleId;
	private String branchId;
	private LocalDateTime createdAt;
	
	private String gender_name;
	private String employee_role_name;
	private String employee_status_name;
	private String employee_branch_name;
	
	public Employee() {
	}

	public Employee(String employeeId, String name, String email, String photoPath, String password,
			String employeeStatusId, String phone, double salary, String address, LocalDate dob, String genderId,
			String employeeRoleId, String branchId, LocalDateTime createdAt) {
		this.employeeId = employeeId;
		this.name = name;
		this.email = email;
		this.photoPath = photoPath;
		this.password = password;
		this.employeeStatusId = employeeStatusId;
		this.phone = phone;
		this.salary = salary;
		this.address = address;
		this.dob = dob;
		this.genderId = genderId;
		this.employeeRoleId = employeeRoleId;
		this.branchId = branchId;
		this.createdAt = createdAt;
	}

	public String getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhotoPath() {
		return photoPath;
	}

	public void setPhotoPath(String photoPath) {
		this.photoPath = photoPath;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmployeeStatusId() {
		return employeeStatusId;
	}

	public void setEmployeeStatusId(String employeeStatusId) {
		this.employeeStatusId = employeeStatusId;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public String getGenderId() {
		return genderId;
	}

	public void setGenderId(String genderId) {
		this.genderId = genderId;
	}

	public String getEmployeeRoleId() {
		return employeeRoleId;
	}

	public void setEmployeeRoleId(String employeeRoleId) {
		this.employeeRoleId = employeeRoleId;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public String getGender_name() {
		return gender_name;
	}

	public void setGender_name(String gender_name) {
		this.gender_name = gender_name;
	}

	public String getEmployee_role_name() {
		return employee_role_name;
	}

	public void setEmployee_role_name(String employee_role_name) {
		this.employee_role_name = employee_role_name;
	}

	public String getEmployee_status_name() {
		return employee_status_name;
	}

	public void setEmployee_status_name(String employee_status_name) {
		this.employee_status_name = employee_status_name;
	}

	public String getEmployee_branch_name() {
		return employee_branch_name;
	}

	public void setEmployee_branch_name(String employee_branch_name) {
		this.employee_branch_name = employee_branch_name;
	}
	
	
}