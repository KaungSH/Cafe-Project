package cafe.project.employeemanagement.controllers;

import java.sql.Time;
import java.time.LocalDate;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.server.ResponseStatusException;

import cafe.project.services.BranchService;
import cafe.project.services.DailyRegisterService;
import cafe.project.employeemanagement.models.LoginDto;
import cafe.project.employeemanagement.services.EmployeeManagementService;
import cafe.project.models.DailyRegisterEntryDto;
import cafe.project.repositories.StatusRepository;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class AuthController {
	
	private final EmployeeManagementService service;
	private final DailyRegisterService registerService;
	private final StatusRepository statusRepository;
	private final BranchService branchService;
	
	public AuthController(EmployeeManagementService userService, DailyRegisterService registerService, BranchService branchService, StatusRepository statusRepository) {
		this.service = userService;
		this.registerService = registerService;
		this.statusRepository = statusRepository;
		this.branchService = branchService;
	}
	
	@GetMapping("/login")
	public String loginPage(Model model) {
		model.addAttribute("user", new LoginDto());
		model.addAttribute("branches", branchService.findAll());
		return "common/user/login";
	}
	
	@PostMapping("/login")
	public String loginPage(@ModelAttribute("user") LoginDto ldto, HttpSession oldsession, HttpServletRequest request, Model model) {
		System.out.println("Password - " + ldto.getPassword());
		System.out.println("Email - " + ldto.getEmail());
		LoginDto ldto2 = service.findByLogin(ldto);
		
		if (ldto2 == null) {
			model.addAttribute("error", "Invalid credentials. Please verify your email and password and try again.");
			model.addAttribute("branches", branchService.findAll());
			return "common/user/login";
		}
		
		if (!ldto2.getEmployee_status().equals("NORMAL")) {
			model.addAttribute("error", "Access denied: Account inactive (Fired/On Leave).");
			model.addAttribute("branches", branchService.findAll());
			return "common/user/login";
		}
		
		DailyRegisterEntryDto dto = registerService.getRegisterEntryDtoByDateOpened(LocalDate.now(), ldto2.getEmployee_id());
		
		if (dto != null) {
			if(!ldto.getBranch_id().equals(dto.getBranch_id())) {
				model.addAttribute("error", "Cannot switch branches; an open register already exists for today.");
				model.addAttribute("branches", branchService.findAll());
				return "common/user/login";
			}
		}
		
		DailyRegisterEntryDto dto2 = registerService.getRegisterEntryDtoByDateClosed(LocalDate.now(), ldto2.getEmployee_id());
		
		if (dto2 != null) {
				model.addAttribute("error", "Login unavailable: The register has already been closed.");
				model.addAttribute("branches", branchService.findAll());
				return "common/user/login";
		}
		
		oldsession.invalidate();
		HttpSession session = request.getSession(true);
		ldto2.setBranch_id(ldto.getBranch_id());
		session.setAttribute("loggedInUser", ldto2);
		System.out.println(ldto2.getEmployee_name());
		System.out.println(ldto2.getBranch_id());
		System.out.println("SESSION ID: " + session.getId());
		System.out.println("USER: " + session.getAttribute("loggedInUser"));
		if(ldto2.getEmployee_role().equals("ADMIN")) {
			return "redirect:/";
		}
		return "redirect:/openshift";
	}
	
	
	@GetMapping("/logout")
	public String logoutPage(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	
	@GetMapping("/openshift")
	public String openShift(Model model, HttpSession session) {
		System.out.println(statusRepository.findAll("register").get(0));
		LoginDto ldto = (LoginDto) session.getAttribute("loggedInUser");
		
		DailyRegisterEntryDto dto = registerService.getRegisterEntryDtoByDate(LocalDate.now(), ldto.getEmployee_id());
		
		if (dto != null) {
			if(ldto.getEmployee_role().equals("MANAGER")) {
				return "redirect:/manager-only/daily-registers/all";
			}
			return "redirect:/";
		}
		
		if(ldto.getEmployee_role().equals("ADMIN")) {
			throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Administrators cannot create a register!");
		}
		
		dto = new DailyRegisterEntryDto();
		dto.setDate(LocalDate.now());
		dto.setOpened_at(Time.valueOf(java.time.LocalTime.now()));
		dto.setRegister_status_id(statusRepository.findAll2("register").get(0).getStatus_id());
		dto.setBranch_id(ldto.getBranch_id());
		dto.setEmployee_id(ldto.getEmployee_id());
		model.addAttribute("registerDto", dto);
		model.addAttribute("branch", branchService.findById(ldto.getBranch_id()).getName());
		model.addAttribute("employee", ldto.getEmployee_name());
		model.addAttribute("status", statusRepository.findAll2("register").get(0).getName());

		return "daily_registers/openshift";
	}

	@PostMapping("/openshift")
	public String openShift(@ModelAttribute("registerDto") DailyRegisterEntryDto dto, HttpSession session) {
		registerService.saveRegister(dto);
		if(((LoginDto) session.getAttribute("loggedInUser")).getEmployee_role().equals("MANAGER")) {
			return "redirect:/manager-only/daily-registers/all";
		}
		return "redirect:/";
	}

	@GetMapping("/closeshift")
	public String closeShift(Model model, HttpSession session) {
		System.out.println(statusRepository.findAll("register").get(0));
		LoginDto ldto = (LoginDto) session.getAttribute("loggedInUser");
		if(ldto.getEmployee_role().equals("ADMIN")) {
			throw new ResponseStatusException(HttpStatus.FORBIDDEN, "Administrators cannot close a register!");
		}
		DailyRegisterEntryDto dto = registerService.getRegisterEntryDtoByDateOpened(LocalDate.now(), ldto.getEmployee_id());
		if(dto == null) {
			return "redirect:/login";
		}
		dto.setClosed_at(Time.valueOf(java.time.LocalTime.now()));
		model.addAttribute("registerDto", dto);
		dto.setRegister_status_id(statusRepository.findAll2("register").get(1).getStatus_id());
		model.addAttribute("branch", branchService.findById(ldto.getBranch_id()).getName());
		model.addAttribute("employee", ldto.getEmployee_name());
		model.addAttribute("status", statusRepository.findAll2("register").get(1).getName());

		return "daily_registers/closeshift";
	}

	@PostMapping("/closeshift")
	public String closeShift(@ModelAttribute("registerDto") DailyRegisterEntryDto dto, HttpSession session) {
		registerService.updateRegister(dto);
		return "redirect:/logout";
	}
	
}
